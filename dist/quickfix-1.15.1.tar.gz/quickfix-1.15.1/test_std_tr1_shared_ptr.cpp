#include <tr1/memory>

int main(int argc, char** argv)
{
  std::tr1::shared_ptr<int> o;
}
